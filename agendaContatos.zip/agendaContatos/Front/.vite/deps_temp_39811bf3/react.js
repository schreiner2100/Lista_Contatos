import {
  require_react
} from "./chunk-QSQYAWSL.js";
export default require_react();
//# sourceMappingURL=react.js.map
