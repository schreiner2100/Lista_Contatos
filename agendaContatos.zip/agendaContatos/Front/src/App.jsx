import React from "react"

import {Home} from './components/Home/Home.jsx'


export function App() {
  return (
   <Home/>
  );
}
